package tests.base.mediator.mocks;

import base.mediator.notification.Notification;

public class NotificationMock implements Notification {
    
}
