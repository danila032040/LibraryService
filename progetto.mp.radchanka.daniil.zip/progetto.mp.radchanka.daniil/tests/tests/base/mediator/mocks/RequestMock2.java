package tests.base.mediator.mocks;

import base.mediator.request.Request;

public class RequestMock2 implements Request<Integer> {
}
