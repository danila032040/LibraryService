package tests.base.mediator.mocks;

import base.mediator.request.Request;

public class RequestMock0 implements Request<Integer> {
}
