package tests.base.mediator.ddd.mocks;

import base.ddd.DomainEvent;

public class DomainEventMock2 implements DomainEvent {
    
}
