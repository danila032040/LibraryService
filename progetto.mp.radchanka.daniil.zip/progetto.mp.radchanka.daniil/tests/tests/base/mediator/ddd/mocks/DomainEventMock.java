package tests.base.mediator.ddd.mocks;

import base.ddd.DomainEvent;

public class DomainEventMock implements DomainEvent {
}
