package tests.base.ddd.mocks;

import base.ddd.DomainEvent;

public class DomainEventMock implements DomainEvent {
}
