package tests.application.pipelineBehaviours.mocks;

import base.mediator.request.Request;
import base.result.ErrorOr;

public class RequestMock implements Request<ErrorOr<String>> {
}
