package application.queries.common.sortData;

public enum SortTypeQueryData {
    Ascending, Descending

}
