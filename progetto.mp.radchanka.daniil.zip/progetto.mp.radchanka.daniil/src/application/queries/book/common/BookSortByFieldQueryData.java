package application.queries.book.common;

public enum BookSortByFieldQueryData {
    Id, Name, Genre, PublicationYear, AuthorId, LibraryId
}
