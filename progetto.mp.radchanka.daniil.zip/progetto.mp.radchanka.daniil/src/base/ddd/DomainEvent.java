package base.ddd;

public interface DomainEvent {
    
}
