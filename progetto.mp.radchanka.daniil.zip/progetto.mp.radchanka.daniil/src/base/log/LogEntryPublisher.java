package base.log;

public interface LogEntryPublisher {
    public void publish(LogEntry logEntry);
    
}
