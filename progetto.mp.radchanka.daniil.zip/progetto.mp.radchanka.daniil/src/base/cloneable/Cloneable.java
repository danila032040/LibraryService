package base.cloneable;

public interface Cloneable<T> {
    public T createClone();
}
