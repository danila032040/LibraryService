package base.mediator.request;

public interface Request<TResult> {
    
}
