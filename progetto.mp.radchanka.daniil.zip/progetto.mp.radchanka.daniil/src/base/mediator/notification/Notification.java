package base.mediator.notification;

public interface Notification {
}
