package base.repository;

public enum SortType {
    Ascending, Descending
}
